console.log("JS Loaded");
fetch("data.json")
  .then(res => res.json())
  .then(data => {
    const patient = data[0];
    document.getElementById("name").textContent = patient.name;
    document.getElementById("dob").textContent = "Date of Birth: " + patient.date_of_birth;
    document.getElementById("gender").textContent = "Gender: " + patient.gender;
    document.getElementById("phone").textContent = "Phone: " + patient.phone_number;
    document.getElementById("emergency").textContent = "Emergency: " + patient.emergency_contact;
    document.getElementById("insurance").textContent = "Insurance: " + patient.insurance_type;
    document.getElementById("resp").textContent = patient.respiratory_rate + " bpm";
    document.getElementById("temp").textContent = patient.temperature + " °F";
    document.getElementById("heart").textContent = patient.heart_rate + " bpm";
    createChart(patient);
  })
  .catch(error => console.error(error));
function createChart(patient) {
  const labels = patient.blood_pressure.map(item => item.year);
  const systolic = patient.blood_pressure.map(item => item.systolic);
  const diastolic = patient.blood_pressure.map(item => item.diastolic);
  const ctx = document.getElementById("bpChart").getContext("2d");
  new Chart(ctx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Systolic",
          data: systolic,
          borderWidth: 2
        },
        {
          label: "Diastolic",
          data: diastolic,
          borderWidth: 2
        }
      ]
    }
  });
}